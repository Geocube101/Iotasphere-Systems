from __future__ import annotations

import collections.abc
import cupy
import datetime
import math
import typing
import uuid

from .. import Exceptions
from .. import Math
from .. import Misc
from .. import Stream


class Charge:
	def __init__(self, charge: float, mass: float, position: Math.Vector.Vector):
		Misc.raise_ifn(isinstance(charge, (int, float)), Exceptions.InvalidArgumentException(Charge.__init__, 'charge', type(charge), (float, int)))
		Misc.raise_ifn(isinstance(mass, (int, float)), Exceptions.InvalidArgumentException(Charge.__init__, 'mass', type(mass), (float, int)))
		Misc.raise_ifn(isinstance(position, Math.Vector.Vector), Exceptions.InvalidArgumentException(Charge.__init__, 'position', type(position), (Math.Vector.Vector,)))

		self.__charge__: float = float(charge)
		self.__mass__: float = mass
		self.__position__: Math.Vector.Vector = position

	@property
	def charge(self) -> float:
		return self.__charge__

	@charge.setter
	def charge(self, charge: float) -> None:
		assert isinstance(charge, (int, float)), 'Invalid charge'
		self.__charge__ = float(charge)

	@property
	def mass(self) -> float:
		return self.__mass__

	@mass.setter
	def mass(self, mass: float) -> None:
		assert isinstance(mass, (int, float)), 'Invalid mass'
		self.__mass__ = mass

	@property
	def position(self) -> Math.Vector.Vector:
		return self.__position__

	@position.setter
	def position(self, position: Math.Vector.Vector) -> None:
		assert isinstance(position, Math.Vector.Vector) and position.dimension == 3, 'Invalid 3D vector'
		self.__position__ = position


class ChargedParticleSimulation:
	def __init__(self, tps: float = ..., particle_radius: float = 1):
		Misc.raise_ifn(tps is ... or tps is None or isinstance(tps, (int, float)), Exceptions.InvalidArgumentException(ChargedParticleSimulation.__init__, 'tps', type(tps), (float, int)))
		Misc.raise_ifn(tps is ... or tps is None or (tps := float(tps)) > 0, ValueError('TPS must be positive and non-zero'))
		Misc.raise_ifn(isinstance(particle_radius, (int, float)), Exceptions.InvalidArgumentException(Charge.__init__, 'particle_radius', type(particle_radius), (float, int)))
		Misc.raise_ifn((particle_radius := float(particle_radius)) >= 0, ValueError('Particle radius must be positive or zero'))

		self.__charges__: cupy.ndarray = ...
		self.__charge_uuids__: dict[uuid.UUID, int] = {}
		self.__charge_add_buffer__: dict[uuid.UUID, Charge] = {}
		self.__charge_del_buffer__: list[uuid.UUID] = []
		self.__last_tick__: datetime.datetime = ...
		self.__tps__: typing.Optional[float] = None if tps is None else ... if tps is ... else (1 / float(tps))
		self.__particle_radius__: float = particle_radius

	def tick(self) -> None:
		now: datetime.datetime = datetime.datetime.now()

		if isinstance(self.__tps__, float):
			delta = self.__tps__
		else:
			if self.__last_tick__ is ...:
				self.__last_tick__ = now
				return

			delta: float = (now - self.__last_tick__).total_seconds()
			self.__last_tick__ = now

		length: int = len(self.__charges__)
		delta_squared: float = delta * delta
		min_distance_squared: float = (self.__particle_radius__ * 2) ** 2
		k: float = 8.9875517923e9
		c: float = 299_792_458.0
		c0: cupy.ndarray = self.__charges__[0, :, 0]
		m0: cupy.ndarray = self.__charges__[0, :, 1]
		x0: cupy.ndarray = self.__charges__[0, :, 2]
		y0: cupy.ndarray = self.__charges__[0, :, 3]
		z0: cupy.ndarray = self.__charges__[0, :, 4]
		cn: cupy.ndarray = self.__charges__[1:, :, 0]
		xn: cupy.ndarray = self.__charges__[1:, :, 2]
		yn: cupy.ndarray = self.__charges__[1:, :, 3]
		zn: cupy.ndarray = self.__charges__[1:, :, 4]
		dx: cupy.ndarray = xn - x0
		dy: cupy.ndarray = yn - y0
		dz: cupy.ndarray = zn - z0
		distance_squared: cupy.ndarray = dx * dx + dy * dy + dz * dz
		distance: cupy.ndarray = cupy.nan_to_num(cupy.sqrt(distance_squared) - (4 * self.__particle_radius__))
		cupy.clip(distance, 0, None, distance)
		magnitude_acceleration: cupy.ndarray = (k * c0 * cn) / (m0 * distance * distance)
		cupy.nan_to_num(magnitude_acceleration, copy=False)
		magnitude_acceleration = cupy.clip(magnitude_acceleration, -c, c)
		magnitude_acceleration[cupy.abs(magnitude_acceleration) >= c] = 0
		ax: cupy.ndarray = cupy.nan_to_num(dx / distance * magnitude_acceleration, posinf=0, neginf=0)
		ay: cupy.ndarray = cupy.nan_to_num(dy / distance * magnitude_acceleration, posinf=0, neginf=0)
		az: cupy.ndarray = cupy.nan_to_num(dz / distance * magnitude_acceleration, posinf=0, neginf=0)
		# print(distance, magnitude_acceleration, ax, ay)
		ax = cupy.sum(ax, axis=0)
		ay = cupy.sum(ay, axis=0)
		az = cupy.sum(az, axis=0)
		dx = delta - ax * delta_squared / 2
		dy = delta - ay * delta_squared / 2
		dz = az * delta_squared / 2
		self.__charges__[0, :, 2] += dx
		self.__charges__[0, :, 3] += dy
		self.__charges__[0, :, 4] += dz
		base = self.__charges__[0]
		self.__charges__[1:] = base[(cupy.arange(length)[None, :] - cupy.arange(1, length)[:, None]) % length]
		# raise NotImplementedError()

	def update(self) -> None:
		self.__charge_add_buffer__.update(dict(self.get_charges()))
		length: int = len(self.__charge_add_buffer__)
		particle_matrix: cupy.ndarray = cupy.zeros((length, length, 5), cupy.float64)
		self.__charge_uuids__.clear()

		for index, (uid, charge) in enumerate(self.__charge_add_buffer__.items()):
			self.__charge_uuids__[uid] = index

			for i in range(length):
				true: int = (index + i) % length
				particle_matrix[i, true, :] = cupy.array((charge.charge, charge.mass, *charge.position), cupy.float64)

		self.__charges__ = particle_matrix

	def remove_charge(self, charge: uuid.UUID) -> None:
		if charge in self.__charge_uuids__:
			self.__charge_del_buffer__.append(charge)
		elif charge in self.__charge_add_buffer__:
			del self.__charge_add_buffer__[charge]

	def add_charge(self, charge: float, mass: float, position: Math.Vector.Vector) -> uuid.UUID:
		uid: uuid.UUID = uuid.uuid4()
		self.__charge_add_buffer__[uid] = Charge(charge, mass, position)
		return uid

	def get_charges(self) -> collections.abc.Iterator[tuple[uuid.UUID, Charge]]:
		if self.__charges__ is ...:
			return

		for i, row in enumerate(self.__charges__[0, :, :]):
			charge, mass, px, py, pz = [float(element) for element in row]
			uid: uuid.UUID = Stream.LinqStream(self.__charge_uuids__.items()).filter(lambda pair: pair[1] == i).transform(lambda pair: pair[0]).first()
			yield uid, Charge(charge, mass, Math.Vector.Vector(px, py, pz))
